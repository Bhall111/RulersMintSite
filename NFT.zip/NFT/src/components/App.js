import React, {Component} from 'react';
import Web3 from 'web3'
import './App.css';
import RulerToken from '../abis/MERMAIDABI.json'
import logo from '../logo.png'

class App extends Component {

    constructor(props) {
        super(props)
        this.connected = false
        this.state = {
            account: null,
            token: null,
            totalSupply: 0,
            tokenURIs: [],
            cardArray: [],
            cardsChosen: [],
            cardsChosenId: [],
            cardsWon: [],
        }
    }

    async loadWeb3() {
        // Modern dapp browsers...
        if (window.ethereum) {
            window.web3 = new Web3(window.ethereum);
            await window.ethereum.enable();

        } else if (window.web3) {
            window.web3 = new Web3(window.web3.currentProvider);
        } else {
            console.log('Non-Ethereum browser detected. You should consider trying MetaMask!');
        }
    }

    componentDidMount() {
        this.init()

    }

    async init() {
        await this.loadWeb3()
        await this.loadBlockingChainData()
    }

    async loadBlockingChainData() {
        const web3 = window.web3
        if (!web3) {
            alert('Please install a Metamask wallet extension in your browser to continue')
            // TODO: redirect to metamask extension page
            return
        }
        const accounts = await web3.eth.getAccounts()
        //alert(accounts[0])
        if (accounts.length > 0) {
            this.setState({account: accounts[0]})
            this.connected = true;
        }


        const networkId = await web3.eth.net.getId()
        //const networkData = RulerToken.networks[networkId]

        //console.log('Network ID ', networkId)
        // const address = '0x9a4C8F907b3c3E8bE71101995FBB83c62f9A38Dd'
        const address = '0x1D9c1a85c3466173dc92620546fF6e738ebEd88C'
        if (address) {
            const abi = RulerToken.abi
            //const address = networkData.address
            const token = web3.eth.Contract(abi, address)
            this.setState({token})

        } else {
            alert('Smart contract not deployed on the network')
        }
    }

    mint(numberOfTokens) {
        if (!this.connected) {
            alert("Please connect your Metamask wallet to continue")
            return
        }
        const payableAmount = 0.08 * numberOfTokens // 0.8 should be validated in contract I think
        this.state
            .token
            .methods
            .mintRuler(numberOfTokens)
            // .send({from: this.state.account, gas: 1000000, value: window.web3.utils.toWei(payableAmount.toString(), 'ether') , gasPrice: this.toWei('2')})
            .send({
                from: this.state.account,
                value: window.web3.utils.toWei(payableAmount.toString(), 'Ether')
            })
            .on('transactionHash', (transactionHash) => {
                alert("Minting is successful " + transactionHash);
            })
            .on('error', (error) => {
                console.log(error)
            })
    }

    toWei(n) {
        return window.web3.utils.toWei(n, 'gwei')
    }

    render() {
        return (
            <div>
                <nav className="navbar navbar-dark flex-md-nowrap p-0 shadow">
                    <a
                        className="navbar-brand col-sm-3 col-md-2 mr-0"
                        href="/"
                        rel="noopener noreferrer"
                    >
                        <img src={logo} width="50" height="50" className="d-inline-block align-top" alt=""/>
                        &nbsp; Rulers of the Seas
                    </a>
                    <ul className="navbar-nav px-3">
                        <li className="nav-item text-nowrap d-none d-sm-none d-sm-block">
                            <small className="text-muted"><span id="account">{this.state.account}</span></small>
                        </li>
                    </ul>
                </nav>
                <div id="content" className="mt-3 container">

                    <div className="card mb-4">
                        <div className="card-body">
                            <form className="mb-3" onSubmit={(e) => {
                                e.preventDefault()
                                let amount = this.input.value.toString()
                                this.mint(amount)
                            }}>
                                <div>
                                    <h2 className="text-center">Mint your Rulers</h2>
                                    <br/>
                                    <button onClick={(event => {
                                        event.preventDefault();
                                        if (!this.connected) {
                                            this.init()
                                        }
                                    })} className="btn btn-outline-dark btn-block btn-lg">
                                        {this.state.account === null ? ("Connect To Metamask")
                                            : ('Connected: ...' + this.state.account.substr(25))}
                                    </button>
                                    <br/>
                                </div>
                                <div className="input-group mb-4">
                                    <input ref={(input) => {
                                        this.input = input
                                    }} type="number" min={1} max={20} in className="form-control form-control-lg"
                                           placeholder="0" required/>
                                    <div className="input-group-append">
                                        <div className="input-group-text">
                                            Number of NFT to mint(1-20)
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" className="btn btn-primary btn-block btn-lg">Mint!</button>

                            </form>
                        </div>
                    </div>


                </div>
            </div>
        );
    }

}

export default App;
